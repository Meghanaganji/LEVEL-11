## Voting page
* https://voting-system.libyzxy0.repl.co/vote

## Results page
* https://voting-system.libyzxy0.repl.co/result
